#line 1 "C:/Users/fatem/OneDrive/Desktop/ali-az/g2/MyProject.c"

char GLCD_DataPort at PORTB;

sbit GLCD_CS1 at RC5_bit;
sbit GLCD_CS2 at RC4_bit;
sbit GLCD_RST at RC0_bit;
sbit GLCD_RW at RC2_bit;
sbit GLCD_EN at RC1_bit;
sbit GLCD_RS at RC3_bit;

sbit GLCD_CS1_Direction at TRISC5_bit;
sbit GLCD_CS2_Direction at TRISC4_bit;
sbit GLCD_RST_Direction at TRISC0_bit;
sbit GLCD_RW_Direction at TRISC2_bit;
sbit GLCD_EN_Direction at TRISC1_bit;
sbit GLCD_RS_Direction at TRISC3_bit;

 unsigned int adc_value;
 int x,y1, y2;

void main() {
 TRISB = 0x00;
 TRISC = 0x00;
 TRISA = 0xFF;

 ADCON1 = 0x06;
 Glcd_Init();
 Glcd_Fill(0x00);

 while(1) {
 Glcd_Fill(0x00);

 y2 = 0;
 for(x = 0; x < 128; x++) {
 adc_value = ADC_Read(0);

 y1 = 63 - ((adc_value * 64) / 1024);

 Glcd_Dot(x, y1, 1);

 if(x > 0) {
 Glcd_Line(x - 1, y2, x, y1, 1);
 }

 y2 = y1;

 Delay_ms(1);
 }
 }
}
