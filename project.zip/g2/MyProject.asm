
_main:

;MyProject.c,21 :: 		void main() {
;MyProject.c,22 :: 		TRISB = 0x00;
	CLRF       TRISB+0
;MyProject.c,23 :: 		TRISC = 0x00;
	CLRF       TRISC+0
;MyProject.c,24 :: 		TRISA = 0xFF;
	MOVLW      255
	MOVWF      TRISA+0
;MyProject.c,26 :: 		ADCON1 = 0x06;
	MOVLW      6
	MOVWF      ADCON1+0
;MyProject.c,27 :: 		Glcd_Init();
	CALL       _Glcd_Init+0
;MyProject.c,28 :: 		Glcd_Fill(0x00);
	CLRF       FARG_Glcd_Fill_pattern+0
	CALL       _Glcd_Fill+0
;MyProject.c,30 :: 		while(1) {
L_main0:
;MyProject.c,31 :: 		Glcd_Fill(0x00);
	CLRF       FARG_Glcd_Fill_pattern+0
	CALL       _Glcd_Fill+0
;MyProject.c,33 :: 		y2 = 0;
	CLRF       _y2+0
	CLRF       _y2+1
;MyProject.c,34 :: 		for(x = 0; x < 128; x++) {
	CLRF       _x+0
	CLRF       _x+1
L_main2:
	MOVLW      128
	XORWF      _x+1, 0
	MOVWF      R0+0
	MOVLW      128
	SUBWF      R0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L__main8
	MOVLW      128
	SUBWF      _x+0, 0
L__main8:
	BTFSC      STATUS+0, 0
	GOTO       L_main3
;MyProject.c,35 :: 		adc_value = ADC_Read(0);
	CLRF       FARG_ADC_Read_channel+0
	CALL       _ADC_Read+0
	MOVF       R0+0, 0
	MOVWF      _adc_value+0
	MOVF       R0+1, 0
	MOVWF      _adc_value+1
;MyProject.c,37 :: 		y1 = 63 - ((adc_value * 64) / 1024);
	MOVLW      6
	MOVWF      R2+0
	MOVF       R0+0, 0
	MOVWF      R3+0
	MOVF       R0+1, 0
	MOVWF      R3+1
	MOVF       R2+0, 0
L__main9:
	BTFSC      STATUS+0, 2
	GOTO       L__main10
	RLF        R3+0, 1
	RLF        R3+1, 1
	BCF        R3+0, 0
	ADDLW      255
	GOTO       L__main9
L__main10:
	MOVLW      10
	MOVWF      R2+0
	MOVF       R3+0, 0
	MOVWF      R0+0
	MOVF       R3+1, 0
	MOVWF      R0+1
	MOVF       R2+0, 0
L__main11:
	BTFSC      STATUS+0, 2
	GOTO       L__main12
	RRF        R0+1, 1
	RRF        R0+0, 1
	BCF        R0+1, 7
	ADDLW      255
	GOTO       L__main11
L__main12:
	MOVF       R0+0, 0
	SUBLW      63
	MOVWF      R0+0
	MOVF       R0+1, 0
	BTFSS      STATUS+0, 0
	ADDLW      1
	CLRF       R0+1
	SUBWF      R0+1, 1
	MOVF       R0+0, 0
	MOVWF      _y1+0
	MOVF       R0+1, 0
	MOVWF      _y1+1
;MyProject.c,39 :: 		Glcd_Dot(x, y1, 1);
	MOVF       _x+0, 0
	MOVWF      FARG_Glcd_Dot_x_pos+0
	MOVF       R0+0, 0
	MOVWF      FARG_Glcd_Dot_y_pos+0
	MOVLW      1
	MOVWF      FARG_Glcd_Dot_color+0
	CALL       _Glcd_Dot+0
;MyProject.c,41 :: 		if(x > 0) {
	MOVLW      128
	MOVWF      R0+0
	MOVLW      128
	XORWF      _x+1, 0
	SUBWF      R0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L__main13
	MOVF       _x+0, 0
	SUBLW      0
L__main13:
	BTFSC      STATUS+0, 0
	GOTO       L_main5
;MyProject.c,42 :: 		Glcd_Line(x - 1, y2, x, y1, 1);
	MOVLW      1
	SUBWF      _x+0, 0
	MOVWF      FARG_Glcd_Line_x_start+0
	MOVLW      0
	BTFSS      STATUS+0, 0
	ADDLW      1
	SUBWF      _x+1, 0
	MOVWF      FARG_Glcd_Line_x_start+1
	MOVF       _y2+0, 0
	MOVWF      FARG_Glcd_Line_y_start+0
	MOVF       _y2+1, 0
	MOVWF      FARG_Glcd_Line_y_start+1
	MOVF       _x+0, 0
	MOVWF      FARG_Glcd_Line_x_end+0
	MOVF       _x+1, 0
	MOVWF      FARG_Glcd_Line_x_end+1
	MOVF       _y1+0, 0
	MOVWF      FARG_Glcd_Line_y_end+0
	MOVF       _y1+1, 0
	MOVWF      FARG_Glcd_Line_y_end+1
	MOVLW      1
	MOVWF      FARG_Glcd_Line_color+0
	CALL       _Glcd_Line+0
;MyProject.c,43 :: 		}
L_main5:
;MyProject.c,45 :: 		y2 = y1;
	MOVF       _y1+0, 0
	MOVWF      _y2+0
	MOVF       _y1+1, 0
	MOVWF      _y2+1
;MyProject.c,47 :: 		Delay_ms(1);
	MOVLW      3
	MOVWF      R12+0
	MOVLW      151
	MOVWF      R13+0
L_main6:
	DECFSZ     R13+0, 1
	GOTO       L_main6
	DECFSZ     R12+0, 1
	GOTO       L_main6
	NOP
	NOP
;MyProject.c,34 :: 		for(x = 0; x < 128; x++) {
	INCF       _x+0, 1
	BTFSC      STATUS+0, 2
	INCF       _x+1, 1
;MyProject.c,48 :: 		}
	GOTO       L_main2
L_main3:
;MyProject.c,49 :: 		}
	GOTO       L_main0
;MyProject.c,50 :: 		}
L_end_main:
	GOTO       $+0
; end of _main
